from tkinter import *
import tkinter
from datetime import datetime, date

##### cores #####
cor1 = "#3d3d3d"; 
cor2 = "#fafcff";
cor3 = "#21c25c";
cor4 = "#eb463b";
cor5 = "#dedcdc";
cor6 = "#3080f0";

fundo = cor1;
cor = cor2;

#CONFIGURANDO TELA
janela=Tk();
janela.title("");
janela.geometry("440x280");
janela.resizable(width=FALSE, height=FALSE);
janela.configure(bg=cor1);

def relogio():
    tempo = datetime.now();

    #ARMAZENANDO  HORARIO E DATA
    hora = tempo.strftime("%H:%M:%S");
    dia_semana = tempo.strftime("%A");
    dia = tempo.day;
    mes = tempo.strftime("%b");
    
    
    ano = tempo.strftime("%Y");
    
    l2.config(text= hora);
    l2.after(200, relogio);
    l1.config(text= dia_semana + " " + str(dia) +
              "/" + str(mes) + "/" + str(ano));
    
    #contagem ano novo
    inicio_ano= date(date.today().year,1, 1);
    dias_passados = (date.today()- inicio_ano).days;
    mes = tempo.strftime("%b");

    l3.config(text= f"Faltam {365 - dias_passados} dias para o ano novo");
        
#LABEL HORA
l2 =Label(janela, text="10:50:20", font=("Arial 80"), bg=fundo, fg=cor);
l2.grid(row=0, column=0, sticky=NW, padx=5);

#LABEL DATA
l1 = Label(janela, text="10:50:20", font=("Arial 20"), bg=fundo, fg=cor);
l1.grid(row=1, column=0, sticky=NW, padx=5);

#LABEL CONTAGEM ANO NOVO
l3 = Label(janela, text="", font=("Arial 20"), bg=fundo, fg=cor);
l3.grid(row=20, column=0, sticky=NW, padx=5);

relogio();
janela.mainloop();

